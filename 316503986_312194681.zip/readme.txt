Advanced-programming---Assignment-1
Noamya Shani (316503986) and Eitan Shankolevski (312194681)

The purpose of this assignment is to simulate a 'shell', that is, a kind of shell that allows certain commands to be run through it.
Some of the commands - writing and adding to a file, transferring the standard output or the error file to another file, echo, repeating previous commands, defining new variables, pipe, if-else and more.<sub>

Some assumptions -
in the 'read' command, only one variable can be defined at a time.

'pipe' is running for all commands except the if-else command.
